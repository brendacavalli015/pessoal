//create a circle that follows mouse position
//This code is from coding train P5 tuts 

function setup() {
  createCanvas(800, 800);
  //usamos createCanvas para fazer o espaço exatamente do tamanho que queremos 
}

function draw() {
  background(150);
  // background usamos para mudarmo a cor entre cinza(150),preto(1), cinza claro(220),branco (2200), entre utros
  
  ellipse(mouseX, mouseY, 156);
  // mudar o tamanho da bolinha do mause
}
// descobri oque são mexendo e vendo oque mudava, descobrindo ao poucos